package sk.stuba.fei.uim.oop;

import sk.stuba.fei.uim.oop.application.MainLogic;

public class ExamRT {
    public static void main(String[] args) {
        new MainLogic();
    }
}
